//
//  split.h
//  six5
//
//  Created by Worlder on 2018/12/31.
//  Copyright © 2018 Worlder. All rights reserved.
//

#ifndef split_h
#define split_h

#include <vector>
#include <string>
std::vector<std::string> split(const std::string&);

#endif /* split_h */
