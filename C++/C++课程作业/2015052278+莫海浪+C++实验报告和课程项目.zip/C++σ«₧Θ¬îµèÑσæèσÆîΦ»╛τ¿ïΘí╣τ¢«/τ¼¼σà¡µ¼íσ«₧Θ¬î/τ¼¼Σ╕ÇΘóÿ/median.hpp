//
//  median.hpp
//  one6
//
//  Created by Worlder on 2018/12/31.
//  Copyright © 2018 Worlder. All rights reserved.
//

#ifndef median_hpp
#define median_hpp

#include <vector>
double median(std::vector<double>);

#endif /* median_hpp */
