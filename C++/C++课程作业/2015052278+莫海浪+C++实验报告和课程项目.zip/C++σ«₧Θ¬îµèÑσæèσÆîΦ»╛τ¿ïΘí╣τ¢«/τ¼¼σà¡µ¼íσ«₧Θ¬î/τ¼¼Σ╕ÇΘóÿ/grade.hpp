//
//  grade.hpp
//  one6
//
//  Created by Worlder on 2018/12/31.
//  Copyright © 2018 Worlder. All rights reserved.
//

#ifndef grade_hpp
#define grade_hpp

#include <string>
#include <vector>

using namespace std;

double grade(double, double, const vector<double>& , double&);

#endif /* grade_hpp */
